# PhantomJS Puppet Module for Boxen

## Usage

```puppet
include phantomjs
```

## Required Puppet Modules

* `boxen`
* `homebrew`
* `stdlib`
