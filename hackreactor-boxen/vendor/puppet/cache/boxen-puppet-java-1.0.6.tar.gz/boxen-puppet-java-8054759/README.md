# Java Puppet Module for Boxen

Installs Java 7u13.

## Usage

```puppet
include java
```

## Required Puppet Modules

None.
