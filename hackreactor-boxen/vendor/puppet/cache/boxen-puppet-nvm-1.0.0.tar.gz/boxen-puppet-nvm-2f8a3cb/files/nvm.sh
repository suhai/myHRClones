export BOXEN_NVM_DEFAULT_VERSION="v0.8"
export BOXEN_NVM_DIR=$BOXEN_HOME/nvm

# Add NPM's local bins to the path.

export PATH=node_modules/.bin:$PATH
