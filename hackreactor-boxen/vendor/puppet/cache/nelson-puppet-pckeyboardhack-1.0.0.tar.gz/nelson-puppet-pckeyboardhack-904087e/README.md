# PCKeyboardHack Puppet Module for Boxen

## Usage

```puppet
include pckeyboardhack
```

## Required Puppet Modules

* boxen

## Developing

Write code.

Run `script/cibuild`.
