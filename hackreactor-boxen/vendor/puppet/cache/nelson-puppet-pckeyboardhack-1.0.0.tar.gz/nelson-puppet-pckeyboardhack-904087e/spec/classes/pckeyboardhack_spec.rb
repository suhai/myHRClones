require 'spec_helper'

describe 'pckeyboardhack' do
  it do
    should contain_package('PCKeyboardHack').with({
      :provider => 'pkgdmg',
      :source   => 'http://pqrs.org/macosx/keyremap4macbook/files/PCKeyboardHack-9.0.0.dmg',
    })
  end
end
